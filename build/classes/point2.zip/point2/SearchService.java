/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package point2;

import jade.core.AID;
import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author andres
 */
public class SearchService extends Agent {
    
    
    
    public SearchService() {
    }
    
    @Override
    protected void setup()
    {       
        
     System.out.println(" ¡Hello!, I am the agent :" +this.getLocalName() + "searching registered services ");
     doWait(5000);     
     LinkedList<String> nameAgents = this.searchServices();
     int start = 1;
     int finall = 1000;
     
     int result = finall / nameAgents.size();
     int acuInicial = start;
     int acuFinal = result;
     
        for (int i = 0; i < nameAgents.size(); i++) {            
            
            sendMessages(nameAgents.get(i), acuInicial, acuFinal);
            acuInicial = acuFinal +1;
            acuFinal += result;            
        }
        
    
     
          
    }
    
    
    
    public void sendMessages(String nameAgent,int start, int finall){
        
            AID id = new AID(nameAgent, AID.ISLOCALNAME);
            ACLMessage msg = new ACLMessage(ACLMessage.REQUEST);

            msg.addReceiver(id);

            msg.setContent(""+ start + "," + finall);
            this.send(msg);
    }
    
    protected LinkedList<String> searchServices()
    {
     DFAgentDescription dfd = new DFAgentDescription();
     LinkedList<String> na = new LinkedList<>();
      

    try {
      DFAgentDescription[] result = DFService.search(this, dfd);
      System.out.println("total wanted " + result.length);
      
      for (int i=0; i<result.length; i++) {
          
        String out = result[i].getName()+" provides";
        Iterator iter = result[i].getAllServices();
        while (iter.hasNext()) {
          ServiceDescription sd = (ServiceDescription)iter.next();
          if(sd.getName().equalsIgnoreCase("Primos")){
              out += " "+sd.getName();
              na.add(result[i].getName().getLocalName());
                            
          }          
        }
       // System.out.println(this.getLocalName()+": "+out);
      }
    }
    catch (Exception fe) {
      System.err.println(getLocalName() + " search with DF unsucceeded - "
        + fe.getMessage());
      doDelete();
    }
        
    return na;
        
    }
    
}
