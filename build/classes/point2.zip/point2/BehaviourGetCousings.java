/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package point2;

import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

/**
 *
 * @author andres
 */
public class BehaviourGetCousings extends CyclicBehaviour{

    @Override
    public void action() {
        
        ACLMessage m1 = myAgent.blockingReceive();        
        String[] v = m1.getContent().split(",");
        
        for (int i = 0; i < v.length; i++) {
            System.out.println(v[i]);
        }
        
        
    }
    
   
    
}
